package com.example.thebag.frontend;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.example.thebag.R;
import com.example.thebag.backend.DBFunctions;
import com.example.thebag.backend.DBHelper;

public class LoginScreen extends AppCompatActivity {

    private TextView email, password, resetPassword, registar;
    private Button loginButton;
    private long backPressedTime;
    private Toast backToast;
    private DBHelper dbhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        resetPassword = findViewById(R.id.reset_password);
        registar = findViewById(R.id.registar);
        loginButton = findViewById(R.id.login_button);

        dbhelper = new DBHelper(this);

        registar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginScreen.this, RegisterScreen.class);
                startActivity(intent);
            }
        });

        resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginScreen.this, ResetPasswordScreen.class);
                startActivity(intent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailText = email.getText().toString();
                String passwordText = password.getText().toString();
                Intent intent = new Intent(LoginScreen.this, MainMapsScreen.class);

                if(emailText.equals("") || passwordText.equals(""))
                    Toast.makeText(LoginScreen.this, "Preencha todos os Campos", Toast.LENGTH_SHORT).show();
                else{
                    boolean checkEmailPass = dbhelper.checkEmailPassword(emailText, passwordText);
                    if(checkEmailPass) {
                        Toast.makeText(LoginScreen.this, "Login realizado com Sucesso", Toast.LENGTH_SHORT).show();
                        startActivity(intent);
                    } else
                        Toast.makeText(LoginScreen.this, "Email ou Password incorretos", Toast.LENGTH_SHORT).show();
                        
                }
            }
        });

    }

    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()){
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(LoginScreen.this, "Pressione novamente para Sair", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }
}