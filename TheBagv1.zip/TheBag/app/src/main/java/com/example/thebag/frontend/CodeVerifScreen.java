package com.example.thebag.frontend;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.example.thebag.R;

public class CodeVerifScreen extends AppCompatActivity {

    private Button verifyButton;
    private long backPressedTime;
    private Toast backToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_verif_screen);

        verifyButton = findViewById(R.id.verify_button);

        verifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CodeVerifScreen.this, ChangePasswordScreen.class);
                startActivity(intent);
            }
        });
    }

    public void onBackPressed() {
        moveTaskToBack(true);
        if(backPressedTime + 2000 > System.currentTimeMillis()){
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(CodeVerifScreen.this, "Pressione novamente para Sair", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }
}