package com.example.thebag.frontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.thebag.R;
import com.example.thebag.backend.DBHelper;

public class RegisterScreen extends AppCompatActivity {

    private TextView firstName, lastName, email, phoneNumber, password, confirmPassword, login;
    private Toast backToast;
    private long backPressedTime;
    private Button register;
    private DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_screen);

        firstName = findViewById(R.id.first_name);
        lastName = findViewById(R.id.last_name);
        email = findViewById(R.id.email);
        phoneNumber = findViewById(R.id.phone_number);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirm_password);
        login = findViewById(R.id.login);
        register = findViewById(R.id.register_button);

        db = new DBHelper(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterScreen.this, LoginScreen.class);
                startActivity(intent);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean insert;
                if(firstName.getText().toString().equals("") || lastName.getText().toString().equals("") || email.getText().toString().equals("") || phoneNumber.getText().toString().equals("") ||
                password.getText().toString().equals("") || confirmPassword.getText().toString().equals(""))
                    Toast.makeText(RegisterScreen.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                else{
                    if(password.getText().toString().equals(confirmPassword.getText().toString())){
                        boolean checkEmail = db.checkEmail(email.getText().toString());
                        if(!checkEmail) {
                            insert = db.insertData(firstName.getText().toString(), lastName.getText().toString(), email.getText().toString(), Integer.parseInt(phoneNumber.getText().toString()), password.getText().toString());
                            if (insert) {
                                Toast.makeText(RegisterScreen.this, "Registo efetuado com Sucesso", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterScreen.this, QRCodeScreen.class);
                                startActivity(intent);
                            }
                            else{
                                Toast.makeText(RegisterScreen.this, "Registo não efetuado", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            Toast.makeText(RegisterScreen.this, "Utilizador já existente, Inicie Sessão", Toast.LENGTH_SHORT).show();
                        }

                    }else{
                        Toast.makeText(RegisterScreen.this, "As Passwords não coincidem", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
    }

    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()){
            backToast.cancel();
            super.onBackPressed();
            return;
        } else {
            backToast = Toast.makeText(RegisterScreen.this, "Pressione novamente para Sair", Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }
}