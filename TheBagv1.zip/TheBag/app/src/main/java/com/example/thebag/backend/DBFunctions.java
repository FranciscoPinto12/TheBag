package com.example.thebag.backend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBFunctions {

    private static Connection connection;




    public static void registo(String utilizador, String password, int telemovel) throws ClassNotFoundException {

        ligacaoDB();
        System.out.println("Criando registo...");
        try {

            String sqlStatement = "INSERT INTO utilizador (Utilizador, Password, Telemóvel) VALUES ('"+utilizador+"','"+password+"','"+telemovel+"')";
            PreparedStatement statement = connection.prepareStatement(sqlStatement);
            statement.executeUpdate();


            statement.close();
            connection.close();

            System.out.println("Registo efetuado com sucesso!");

        } catch (SQLException e) {
            System.out.println("Impossível fazer registo.");
            e.printStackTrace();
        }
    }







    public static boolean login(String utilizador, String password){
        ligacaoDB();
        boolean validadeLogin = false;

        System.out.println("Efetuando login...");

        try{

            String sqlStatement = "Select utilizador.Utilizador FROM Utilizador WHERE utilizador.Utilizador= "+"'"+utilizador+"'"+" and utilizador.Password= "+"'"+password+"'";
            System.out.println(sqlStatement);
            PreparedStatement statement =  connection.prepareStatement(sqlStatement);
            ResultSet resultSet = statement.executeQuery();

            int count = 0;
            while(resultSet.next()){
                count++;
            }


            if ( count == 1 ){
                validadeLogin = true;
                System.out.println("Login efetuado com sucesso!");
            }


        } catch (Exception e){
            System.out.println("Login falhou.");
            e.printStackTrace();
        }

        System.out.println(validadeLogin);
        return validadeLogin;

    }







    public static void ligacaoDB(){

        try{
            System.out.println("entrei aqui");
            connection = DriverManager.getConnection("jdbc:mysql://localhost/thebag","root","");
            System.out.println("Conexão efetuada com sucesso!");

        } catch(SQLException e){

            System.out.println("Conexão falhou.");
            e.printStackTrace();
        }
    }
}
